import speech_recognition as sr
import pywhatkit
import pyjokes
import datetime
import wikipedia

def listen():
    r=sr.Recognizer()
    with sr.Microphone() as source:
        print("listening...")
        audio=r.listen(source)
        try:
            print("recognizing...")
            query = r.recognize_google(audio, language='en-in')
            print(f"User said:{query}\n")
         return query
        except Exception as e:
            print(e)
            return None
def respond(query):
    if 'time' in query:
        time = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"Current time is {time}")
    elif 'date' in query:
        date = datetime.datetime.now().strftime("%d/%m/%Y")
        print(f"Today date is {date}")
    elif 'joke' in query:
        joke = pyjokes.get_joke()
        print(joke)
    elif 'play' in query:
        song =query.replace('play', '')
               pywhatkit.playonyt(song)
     elif 'search' in query:
    search = query.replace('search', '')
    wikipedia.summary(search, sentences=2)
    print(results)
    else:
    print("Sorry, I didn't understand that.")
def main():
    while True:
      query = listen()
        if query is not None:
            respond(query)
if __name__ == '__main__':
    main()

